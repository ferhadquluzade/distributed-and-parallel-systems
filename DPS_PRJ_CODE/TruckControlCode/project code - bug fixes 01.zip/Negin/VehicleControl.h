#pragma once
class VehicleControl
{
public:
	void speedControl();
	void speedUp();
	void speedDown();


};

