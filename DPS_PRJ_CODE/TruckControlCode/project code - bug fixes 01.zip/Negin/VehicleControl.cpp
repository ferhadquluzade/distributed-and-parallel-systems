#include "VehicleControl.h"

void VehicleControl::speedControl()
{
}

void VehicleControl::speedUp()
{
}

void VehicleControl::speedDown()
{
}


